const fs = require('node:fs');
const { chromium } = require('/tmp/prompt-seen-language-review/integration/node_modules/playwright');
const output = '/tmp/prompt-seen-language-review/pending-close-diagnosis';
const origin = `http://127.0.0.1:${process.env.PENDING_PORT || '8197'}`;
const base = process.env.PENDING_BASE || '/prompt-seen';
const expectedBuild = process.env.PENDING_EXPECTED_BUILD || '790dc273-subpath-preview';
const label = process.env.PENDING_DIAG_LABEL || 'before';
const count = Number(process.env.PENDING_DIAG_COUNT || 3);
const listPath = `${base}/en/prompts/`;
const slug = 'adapted-s11-everyday-portrait';
const detailPath = `${listPath}${slug}/`;

function installDiagnostics() {
  window.__doc = Math.random().toString(36).slice(2);
  const ids = new WeakMap(); let nextId = 0;
  const dialogId = dialog => {
    if (!dialog) return null;
    if (!ids.has(dialog)) ids.set(dialog, ++nextId);
    return ids.get(dialog);
  };
  const state = window.__pendingDiag = { events: [], backCalls: 0, heldCloseCount: 0, holdClose: false };
  window.__heldCloseTargets = [];
  const record = (type, data = {}) => state.events.push({ type, at: performance.now(), path: location.pathname, ...data });
  window.__pendingSnapshot = () => {
    const dialog = document.querySelector('dialog[data-popup]');
    return {
      path: location.pathname, historyLength: history.length, doc: window.__doc,
      ours: !!history.state?.promptSeenPopup, open: !!dialog?.open,
      slug: dialog?.getAttribute('data-popup-slug'), dialogId: dialogId(dialog),
      locked: 'popupOpen' in document.documentElement.dataset,
      backCalls: state.backCalls, heldCloseCount: state.heldCloseCount,
      events: [...state.events],
    };
  };
  for (const method of ['back', 'forward', 'pushState', 'replaceState']) {
    const original = history[method];
    history[method] = function () {
      if (method === 'back') state.backCalls++;
      record(`history-${method}`, { target: arguments.length > 2 ? String(arguments[2]) : undefined, stack: new Error().stack });
      return original.apply(this, arguments);
    };
  }
  for (const method of ['showModal', 'close']) {
    const original = HTMLDialogElement.prototype[method];
    HTMLDialogElement.prototype[method] = function () {
      const result = original.apply(this, arguments);
      if (this.hasAttribute('data-popup')) record(`dialog-${method}`, { dialogId: dialogId(this), open: this.open, slug: this.getAttribute('data-popup-slug') });
      return result;
    };
  }
  document.addEventListener('close', event => {
    const dialog = event.target;
    if (!(dialog instanceof HTMLDialogElement) || !dialog.hasAttribute('data-popup')) return;
    record('close-event', { trusted: event.isTrusted, dialogId: dialogId(dialog), openAtDelivery: dialog.open, slug: dialog.getAttribute('data-popup-slug') });
    if (!state.holdClose) return;
    event.stopImmediatePropagation();
    state.heldCloseCount++;
    window.__heldCloseTargets.push(dialog);
    record('close-held', { dialogId: dialogId(dialog) });
  }, true);
  window.__releaseHeldClose = () => {
    const target = window.__heldCloseTargets.shift();
    if (!target) throw new Error('No real native close event was intercepted');
    state.holdClose = false;
    const beforeCalls = state.backCalls;
    const current = document.querySelector('dialog[data-popup]');
    const sameDialog = target === current;
    record('replay-held-close', { dialogId: dialogId(target), sameDialog, open: target.open });
    // Replay delivery of the captured close after the same dialog has reopened.
    // This changes event ordering only; no history or product state is patched.
    target.dispatchEvent(new Event('close'));
    return { sameDialog, beforeCalls, afterCalls: state.backCalls, extraBackCalls: state.backCalls - beforeCalls };
  };
  addEventListener('popstate', () => record('popstate', { ours: !!history.state?.promptSeenPopup }));
  addEventListener('error', event => record('error', { message: event.message }));
}

async function openPending(browser) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  await page.addInitScript(installDiagnostics);
  const html = await (await page.request.get(`${origin}${listPath}`)).text();
  const referenced = new Set([...html.matchAll(/<script[^>]*\ssrc="([^"]+)"/g)].map(match => new URL(match[1], origin).pathname));
  let release;
  const released = new Promise(resolve => { release = resolve; });
  await page.route('**/_next/static/chunks/*.js', async route => {
    if (!referenced.has(new URL(route.request().url()).pathname)) await released;
    await route.continue().catch(() => {});
  });
  await page.goto(`${origin}${listPath}`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => { const element = document.querySelector('[role="feed"]'); return !!element && Object.keys(element).some(key => key.startsWith('__reactProps')); });
  const before = await page.evaluate(() => window.__pendingSnapshot());
  await page.locator(`[role="feed"] a[href="${detailPath}"]`).first().click();
  await page.waitForFunction(target => {
    const dialog = document.querySelector('dialog[data-popup]');
    return dialog?.open && dialog.dataset.popupSlug === target && !!history.state?.promptSeenPopup;
  }, slug);
  if (await page.locator('dialog[data-popup] [data-stage-picture]').count()) throw new Error('Loaded popup unexpectedly present while its scripts are held');
  return { context, page, release, before };
}

(async () => {
  fs.mkdirSync(output, { recursive: true });
  const build = await (await fetch(`${origin}${base}/generated/build.json`)).json();
  if (build.buildId !== expectedBuild) throw new Error(`Unexpected build: ${build.buildId}`);
  const browser = await chromium.launch({ headless: true });
  const summary = {
    buildId: build.buildId, browser: browser.version(),
    playwright: require('/tmp/prompt-seen-language-review/integration/node_modules/playwright/package.json').version,
    provenance: 'The unguarded PendingDialog onClose={leave} also exists in baseline 53cbc8efce854f8f067acef8372daf49be82f9c3. Discovered by this localization browser matrix; no claim that baseline itself was browser-reproduced.',
    iterations: [],
  };
  console.log(JSON.stringify({ ...summary, iterations: undefined }));
  try {
    for (let iteration = 1; iteration <= count; iteration++) {
      for (const scenario of ['stale-close', 'native-close']) {
        const { context, page, release, before } = await openPending(browser);
        try {
          let replay = null;
          let afterBack = null;
          let reopened = null;
          if (scenario === 'stale-close') {
            await page.evaluate(() => { window.__pendingDiag.holdClose = true; });
            await page.goBack({ waitUntil: 'commit' });
            await page.waitForFunction(path => location.pathname === path && !document.querySelector('dialog[data-popup]')?.open && window.__pendingDiag.heldCloseCount > 0, listPath);
            afterBack = await page.evaluate(() => window.__pendingSnapshot());
            await page.goForward({ waitUntil: 'commit' });
            await page.waitForFunction(target => location.pathname.endsWith(`/${target}/`) && document.querySelector('dialog[data-popup]')?.open && document.querySelector('dialog[data-popup]')?.dataset.popupSlug === target, slug);
            reopened = await page.evaluate(() => window.__pendingSnapshot());
            replay = await page.evaluate(() => window.__releaseHeldClose());
            if (replay.extraBackCalls > 0) {
              await page.waitForFunction(path => location.pathname === path && !document.querySelector('dialog[data-popup]')?.open, listPath);
            }
          } else {
            await page.evaluate(() => document.querySelector('dialog[data-popup]').close());
            await page.waitForFunction(path => location.pathname === path && !document.querySelector('dialog[data-popup]')?.open && !('popupOpen' in document.documentElement.dataset), listPath);
          }
          const after = await page.evaluate(() => window.__pendingSnapshot());
          const stableHistory = after.doc === before.doc && after.historyLength === before.historyLength + 1;
          const passed = scenario === 'stale-close'
            ? replay.sameDialog && replay.extraBackCalls === 0 && stableHistory && after.path === detailPath && after.open && after.locked && after.ours && after.slug === slug
            : stableHistory && after.path === listPath && !after.open && !after.locked && after.backCalls === 1;
          const result = { iteration, scenario, buildId: build.buildId, passed, before, afterBack, reopened, replay, after };
          fs.writeFileSync(`${output}/${label}-${scenario}-${iteration}.json`, JSON.stringify(result, null, 2));
          summary.iterations.push({ iteration, scenario, passed, path: after.path, open: after.open, locked: after.locked, backCalls: after.backCalls, replay });
          console.log(JSON.stringify(summary.iterations.at(-1)));
          if (!passed) await page.screenshot({ path: `${output}/${label}-${scenario}-${iteration}.png` });
        } finally {
          release();
          await context.close();
        }
      }
    }
  } finally {
    await browser.close();
    fs.writeFileSync(`${output}/${label}-summary.json`, JSON.stringify(summary, null, 2));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
