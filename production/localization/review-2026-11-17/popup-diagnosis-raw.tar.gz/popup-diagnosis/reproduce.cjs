const fs = require('node:fs');
const { chromium } = require('/tmp/prompt-seen-language-review/integration/node_modules/playwright');
const out = '/tmp/prompt-seen-language-review/popup-diagnosis';
const expectedBuild = process.env.POPUP_EXPECTED_BUILD || '0af7dbe6-root';
const label = process.env.POPUP_DIAG_LABEL || 'old';
const count = Number(process.env.POPUP_DIAG_COUNT || 20);
(async () => {
  const build = await (await fetch('http://127.0.0.1:8197/generated/build.json')).json();
  console.log(JSON.stringify({ buildId: build.buildId, expectedBuild }));
  if (build.buildId !== expectedBuild) throw new Error('Unexpected artifact; refusing diagnosis');
  const browser = await chromium.launch({ headless: true });
  const summary = [];
  try {
    for (let iteration = 1; iteration <= count; iteration++) {
      const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
      const page = await context.newPage();
      await page.addInitScript(() => {
        window.__doc = Math.random().toString(36).slice(2);
        const events = []; window.__popupDiag = events;
        const record = (type, data = {}) => events.push({ type, at: performance.now(), path: location.pathname, ...data });
        for (const method of ['pushState', 'replaceState']) {
          const original = history[method];
          history[method] = function (state, title, url) {
            const from = location.pathname;
            const result = original.apply(this, arguments);
            record(method, { from, url: String(url), state });
            return result;
          };
        }
        const animate = Element.prototype.animate;
        Element.prototype.animate = function (keyframes, options) {
          const animation = animate.apply(this, arguments);
          if (this.closest?.('[data-popup]')) {
            const target = this.getAttribute('class') || this.tagName;
            record('animation-start', { target, keyframes, options });
            animation.finished.then(
              () => record('animation-finished', { target, playState: animation.playState }),
              error => record('animation-rejected', { target, error: String(error), playState: animation.playState }),
            );
          }
          return animation;
        };
        addEventListener('error', event => record('error', { message: event.message }));
        addEventListener('unhandledrejection', event => record('unhandledrejection', { message: String(event.reason) }));
      });
      await page.goto('http://127.0.0.1:8197/en/prompts/');
      await page.waitForFunction(() => {
        const element = document.querySelector('[role="feed"]');
        return !!element && Object.keys(element).some(key => key.startsWith('__reactProps'));
      });
      const before = await page.evaluate(() => ({ path: location.pathname, historyLength: history.length, doc: window.__doc }));
      await page.evaluate(url => history.pushState(null, '', url), '/en/prompts/adapted-s11-everyday-portrait/');
      await page.waitForFunction(() => document.querySelector('dialog[data-popup]')?.open && document.querySelector('dialog[data-popup]')?.dataset.popupSlug === 'adapted-s11-everyday-portrait');
      await page.evaluate(() => location.pathname);
      await page.evaluate(() => ({ ours: !!history.state?.promptSeenPopup, open: document.querySelector('dialog[data-popup]')?.open }));
      await page.keyboard.press('Escape');
      let closed = true;
      try { await page.waitForFunction(() => !document.querySelector('dialog[data-popup]')?.open, {}, { timeout: 2000 }); }
      catch { closed = false; }
      const after = await page.evaluate(() => {
        const dialog = document.querySelector('dialog[data-popup]');
        const panel = dialog?.querySelector('[lang]');
        return {
          path: location.pathname, historyLength: history.length, doc: window.__doc, state: history.state,
          open: dialog?.open, closing: dialog?.hasAttribute('data-closing'), locked: 'popupOpen' in document.documentElement.dataset,
          panelOpacity: panel ? getComputedStyle(panel).opacity : null,
          animations: document.getAnimations().map(animation => ({ playState: animation.playState, currentTime: animation.currentTime, target: animation.effect?.target?.className })),
          events: window.__popupDiag,
        };
      });
      const result = { iteration, buildId: build.buildId, closed, before, after };
      fs.writeFileSync(`${out}/${label}-${iteration}.json`, JSON.stringify(result, null, 2));
      summary.push({ iteration, closed, path: after.path, closing: after.closing, replaces: after.events.filter(event => event.type === 'replaceState').map(event => ({ from: event.from, to: event.url })) });
      console.log(JSON.stringify(summary.at(-1)));
      if (!closed) {
        await page.screenshot({ path: `${out}/${label}-${iteration}-failed.png` });
        await context.close();
        break;
      }
      await context.close();
    }
  } finally {
    await browser.close();
    fs.writeFileSync(`${out}/${label}-summary.json`, JSON.stringify(summary, null, 2));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
