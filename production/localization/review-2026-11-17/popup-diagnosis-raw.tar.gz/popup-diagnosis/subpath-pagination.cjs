const fs = require('node:fs');
const { firefox } = require('/tmp/prompt-seen-language-review/integration/node_modules/playwright');
const output = '/tmp/prompt-seen-language-review/popup-diagnosis';
const origin = 'http://127.0.0.1:8197';
const base = process.env.POPUP_BASE || '/prompt-seen';
const expectedBuild = process.env.POPUP_EXPECTED_BUILD || '58855cb2-subpath-production';
const label = process.env.POPUP_DIAG_LABEL || 'subpath-pagination-before';
const count = Number(process.env.POPUP_DIAG_COUNT || 3);
const holdScripts = process.env.POPUP_HOLD_SCRIPTS !== '0';
const galleryPath = `${base}/en/prompts/page/2/`;
const detailPath = `${base}/en/prompts/adapted-s11-everyday-portrait/`;
(async () => {
  const build = await (await fetch(`${origin}${base}/generated/build.json`)).json();
  if (build.buildId !== expectedBuild) throw new Error(`Unexpected build: ${build.buildId}`);
  const browser = await firefox.launch({ headless: true });
  const summary = { buildId: build.buildId, browser: browser.version(), playwright: require('/tmp/prompt-seen-language-review/integration/node_modules/playwright/package.json').version, holdScripts, iterations: [] };
  console.log(JSON.stringify({ ...summary, iterations: undefined }));
  try {
    for (let iteration = 1; iteration <= count; iteration++) {
      const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
      const page = await context.newPage();
      await page.addInitScript(() => {
        window.__doc = Math.random().toString(36).slice(2);
        window.__popupDiag = [];
        const ids = new WeakMap(); let nextId = 0;
        const dialogId = dialog => { if (!ids.has(dialog)) ids.set(dialog, ++nextId); return ids.get(dialog); };
        const record = (type, data = {}) => window.__popupDiag.push({ type, at: performance.now(), url: location.pathname + location.search + location.hash, scrollY, pageMarker: document.querySelector('[data-list-page]')?.getAttribute('data-list-page'), feedPages: [...new Set([...document.querySelectorAll('[data-feed-page]')].map(element => element.getAttribute('data-feed-page')))], ...data });
        window.__popupRecord = record;
        for (const method of ['pushState', 'replaceState']) {
          const original = history[method];
          history[method] = function (state, title, url) {
            const from = location.pathname + location.search + location.hash;
            const result = original.apply(this, arguments);
            record(method, { from, to: String(url), stack: new Error().stack });
            return result;
          };
        }
        for (const method of ['showModal', 'close']) {
          const original = HTMLDialogElement.prototype[method];
          HTMLDialogElement.prototype[method] = function () {
            const result = original.apply(this, arguments);
            if (this.hasAttribute('data-popup')) record(method, { dialogId: dialogId(this), instant: this.hasAttribute('data-instant'), slug: this.dataset.popupSlug });
            return result;
          };
        }
        addEventListener('error', event => record('error', { message: event.message }));
      });
      let release = () => {};
      if (holdScripts) {
        const html = await (await page.request.get(`${origin}${galleryPath}`)).text();
        const referenced = new Set([...html.matchAll(/<script[^>]*\ssrc="([^"]+)"/g)].map(match => new URL(match[1], origin).pathname));
        const held = new Promise(resolve => { release = resolve; });
        await page.route('**/_next/static/chunks/*.js', async route => {
          if (!referenced.has(new URL(route.request().url()).pathname)) await held;
          await route.continue().catch(() => {});
        });
      }
      await page.goto(`${origin}${galleryPath}`, { waitUntil: holdScripts ? 'domcontentloaded' : 'load' });
      await page.waitForFunction(() => { const element = document.querySelector('[role="feed"]'); return !!element && Object.keys(element).some(key => key.startsWith('__reactProps')); });
      const before = await page.evaluate(() => { window.__popupRecord('before-foreign-push'); return { url: location.href, doc: window.__doc, historyLength: history.length }; });
      await page.evaluate(url => history.pushState(null, '', url), detailPath);
      await page.waitForFunction(() => document.querySelector('dialog[data-popup]')?.open);
      await page.evaluate(() => window.__popupRecord('pending-open', { instant: document.querySelector('dialog[data-popup]')?.hasAttribute('data-instant') }));
      if (holdScripts) {
        release();
        await page.waitForFunction(() => document.querySelector('dialog[data-popup][data-instant]')?.open && document.querySelector('dialog[data-popup] [data-stage-picture]'), {}, { timeout: 15000 });
        await page.evaluate(() => window.__popupRecord('takeover-complete'));
      }
      await page.keyboard.press('Escape');
      await page.waitForFunction(() => !document.querySelector('dialog[data-popup]')?.open, {}, { timeout: 5000 });
      await page.waitForTimeout(300);
      const after = await page.evaluate(() => ({ url: location.href, path: location.pathname, doc: window.__doc, historyLength: history.length, open: document.querySelector('dialog[data-popup]')?.open, locked: 'popupOpen' in document.documentElement.dataset, pageMarker: document.querySelector('[data-list-page]')?.getAttribute('data-list-page'), feedPages: [...new Set([...document.querySelectorAll('[data-feed-page]')].map(element => element.getAttribute('data-feed-page')))], events: window.__popupDiag }));
      const passed = after.url === before.url && !after.open && !after.locked && after.doc === before.doc && after.historyLength === before.historyLength + 1;
      const result = { buildId: build.buildId, browser: browser.version(), iteration, holdScripts, passed, before, after };
      fs.writeFileSync(`${output}/${label}-${iteration}.json`, JSON.stringify(result, null, 2));
      summary.iterations.push({ iteration, passed, actual: after.url, expected: before.url, pageMarker: after.pageMarker, feedPages: after.feedPages });
      console.log(JSON.stringify(summary.iterations.at(-1)));
      if (!passed) await page.screenshot({ path: `${output}/${label}-${iteration}.png` });
      await context.close();
    }
  } finally {
    await browser.close();
    fs.writeFileSync(`${output}/${label}-summary.json`, JSON.stringify(summary, null, 2));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
