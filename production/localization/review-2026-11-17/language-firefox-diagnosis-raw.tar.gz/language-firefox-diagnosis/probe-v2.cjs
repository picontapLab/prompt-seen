const fs=require('node:fs');
const {firefox,expect}=require('/tmp/prompt-seen-language-review/integration/node_modules/@playwright/test');
const dir='/tmp/prompt-seen-language-review/language-firefox-diagnosis';
const mode=process.argv[2]||'baseline';const count=Number(process.argv[3]||24);
(async()=>{const browser=await firefox.launch({headless:true});let failures=0;
for(let i=0;i<count;i++){
 const target=i%2?{name:'العربية',code:'ar'}:{name:'Русский',code:'ru'};
 const context=await browser.newContext({viewport:{width:1280,height:720}});const page=await context.newPage();
 await page.addInitScript(()=>{
  const logs=[];window.__diag=logs;
  const pop=()=>{let e=document.querySelector('[role=listbox]');while(e){if(getComputedStyle(e).overflowY==='auto')return e;e=e.parentElement}return null};
  const popstate=()=>{const p=pop();return p?{scrollTop:p.scrollTop,scrollHeight:p.scrollHeight,clientHeight:p.clientHeight,entering:p.hasAttribute('data-entering'),exiting:p.hasAttribute('data-exiting'),transform:getComputedStyle(p).transform,top:p.getBoundingClientRect().top,bottom:p.getBoundingClientRect().bottom}:null};
  const desc=e=>e instanceof Element?`${e.tagName}[${e.getAttribute('role')||''}].${e.className}`:String(e);
  for(const type of ['scroll','pointerdown','pointerup','click','focusin','focusout'])document.addEventListener(type,e=>{if(logs.length<200)logs.push({type,t:performance.now(),target:desc(e.target),x:e.clientX,y:e.clientY,sx:scrollX,sy:scrollY,input:document.querySelector('[role=combobox]')?.value,expanded:document.querySelector('[role=combobox]')?.getAttribute('aria-expanded'),options:document.querySelectorAll('[role=option]').length,popover:popstate()})},true);
 });
 let err=null;let before;
 try{
  await page.goto('http://127.0.0.1:8197/');
  await page.waitForFunction(()=>{const b=document.querySelector('[data-another]');return b&&Object.keys(b).some(k=>k.startsWith('__reactProps'))});
  await page.locator('[data-another]').click();
  await page.getByRole('banner').getByRole('button',{name:'Language: English',exact:true}).click();
  const input=page.getByRole('combobox',{name:'Language'});
  if(mode==='filtered'||mode==='settled-filtered'){
   await input.fill(target.name);
   await expect(page.getByRole('option')).toHaveCount(1);
  }
  if(mode==='settled'||mode==='settled-filtered'){await expect(input).toHaveAttribute('aria-expanded','true');await expect(page.getByRole('option',{name:target.name})).toBeVisible();}
  if(mode==='settled'||mode==='settled-filtered')await page.evaluate(()=>Promise.all(document.getAnimations().filter(a=>a.effect?.getTiming().iterations!==Infinity).map(a=>a.finished.catch(()=>{}))));
  if(mode==='wheel'){
   await expect(input).toHaveAttribute('aria-expanded','true');
   const box=await page.getByRole('listbox').evaluate(el=>{while(el&&getComputedStyle(el).overflowY!=='auto')el=el.parentElement;const r=el.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}});
   await page.mouse.move(box.x+box.w/2,box.y+box.h/2);await page.mouse.wheel(0,400);
   await expect.poll(()=>page.getByRole('listbox').evaluate(el=>{while(el&&getComputedStyle(el).overflowY!=='auto')el=el.parentElement;return el.scrollTop})).toBeGreaterThan(0);
   await expect(input).toHaveAttribute('aria-expanded','true');
  }
  before=await page.getByRole('option',{name:target.name}).evaluate(el=>{const r=el.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,scroll:scrollY,hit:document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)?.tagName,options:document.querySelectorAll('[role=option]').length,ancestors:(()=>{let p=el.parentElement,a=[];while(p&&a.length<6){let b=p.getBoundingClientRect();a.push({tag:p.tagName,role:p.getAttribute('role'),class:p.className,y:b.y,h:b.height,overflow:getComputedStyle(p).overflowY,scroll:p.scrollTop,entering:p.hasAttribute('data-entering'),transform:getComputedStyle(p).transform});p=p.parentElement}return a})()}});
  await page.getByRole('option',{name:target.name}).click({timeout:3500});
  await expect(page.locator('html')).toHaveAttribute('lang',target.code,{timeout:3500});
 }catch(e){err=e.message;failures++;await page.screenshot({path:`${dir}/${mode}-${i}-failed.png`});}
 const logs=await page.evaluate(()=>window.__diag).catch(()=>[]);
 const result={i,mode,target:target.code,ok:!err,before,error:err,logs};
 fs.writeFileSync(`${dir}/${mode}-${i}.json`,JSON.stringify(result,null,2));
 console.log(JSON.stringify({i,mode,target:target.code,ok:!err,before,error:err?.slice(0,180)}));
 await context.close();
}
await browser.close();console.log(JSON.stringify({mode,count,failures}));})().catch(e=>{console.error(e);process.exitCode=1});
