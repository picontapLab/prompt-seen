const fs = require('node:fs');
const { webkit, expect } = require('/tmp/prompt-seen-language-review/integration/node_modules/@playwright/test');
const dir = '/tmp/prompt-seen-language-review/french-empty-diagnosis';
const mode = process.argv[2] || 'baseline';
const count = Number(process.argv[3] || 8);
const parallel = Number(process.argv[4] || 1);
const budgetMs = mode === 'budget15' ? 15000 : 5000;
const origin = 'http://127.0.0.1:8199';
const query = '梅枝';
const target = `/prompt-seen/zh-hans/search/?q=${encodeURIComponent(query)}`;
function instrument() {
  const logs = window.__searchDiagnostic = [];
  const log = (type, data) => logs.push({ type, t: performance.now(), ...data });
  const NativeWorker = window.Worker;
  window.Worker = class extends NativeWorker {
    constructor(url, options) {
      super(url, options);
      log('worker-start', { url: String(url) });
      this.addEventListener('message', event => log('worker-receive', { data: event.data }));
      this.addEventListener('error', event => log('worker-error', { message: event.message }));
    }
    postMessage(message, options) {
      log('worker-send', { data: message });
      return super.postMessage(message, options);
    }
  };
  let last = '';
  new MutationObserver(() => {
    const empty = document.querySelector('[data-no-results]');
    const text = empty?.innerText || '';
    if (text !== last) {
      last = text;
      log('empty-dom', { text, links: [...(empty?.querySelectorAll('a') || [])].map(a => a.getAttribute('href')) });
    }
  }).observe(document, { childList: true, subtree: true, characterData: true });
}
(async () => {
  fs.mkdirSync(dir, { recursive: true });
  const build = await (await fetch(`${origin}/prompt-seen/generated/build.json`)).json();
  if (build.buildId !== '790dc273-subpath-preview') throw new Error(`Unexpected artifact ${build.buildId}`);
  const browser = await webkit.launch({ headless: true });
  let cursor = 0; const all = [];
  async function run() {
    while (cursor < count) {
      const i = cursor++;
      const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 2 });
      const page = await context.newPage();
      const network = [];
      const now = () => Date.now();
      for (const event of ['request', 'requestfinished', 'requestfailed']) context.on(event, req => {
        if (req.url().includes('/search/index.json')) network.push({ event, at: now(), url: req.url(), failure: req.failure(), timing: req.timing() });
      });
      page.on('pageerror', e => network.push({event: 'pageerror', at: now(), message: e.message}));
      await page.addInitScript(instrument);
      const started = now();
      await page.goto(`${origin}/prompt-seen/fr/search/?q=${encodeURIComponent(query)}`);
      await expect(page.locator('[data-no-results]')).toBeVisible();
      await expect(page.locator('[data-group]')).toHaveCount(0);
      const emptyAt = now();
      let failed5 = false; let firstError = null;
      const link = page.locator(`[data-no-results] a[href="${target}"]`);
      try { await expect(link).toBeVisible({ timeout: budgetMs }); }
      catch(e) { failed5 = true; firstError = e.message; await page.screenshot({path: `${dir}/${mode}-${i}-5s.png`}); }
      const deadlineAt = now();
      let recovered = false;
      if (failed5) { try { await expect(link).toBeVisible({ timeout: 20000 }); recovered = true; } catch {} }
      const finalAt = now();
      let stableAfterAllHelp = null;
      if (mode === 'budget15') {
        await page.waitForFunction(() => window.__searchDiagnostic.filter(e => e.type === 'worker-receive' && e.data.type === 'help').length === 12, undefined, { timeout: 15000 });
        stableAfterAllHelp = await link.isVisible();
      }
      const logs = await page.evaluate(() => window.__searchDiagnostic);
      const result = { i, mode, budgetMs, stableAfterAllHelp, buildId: build.buildId, browser: browser.version(), playwright: require('/tmp/prompt-seen-language-review/integration/node_modules/playwright/package.json').version, started, emptyAt, deadlineAt, finalAt, initialAssertionFailed: failed5, failed5: budgetMs === 5000 ? failed5 : null, recovered, firstError, network, logs };
      fs.writeFileSync(`${dir}/${mode}-${i}.json`, JSON.stringify(result, null, 2));
      const concise = { i, mode, budgetMs, initialAssertionFailed: failed5, failed5: budgetMs === 5000 ? failed5 : null, recovered, stableAfterAllHelp, emptyAfterMs: emptyAt-started, linkAfterEmptyMs: finalAt-emptyAt, helpReceived: logs.filter(e => e.type === 'worker-receive' && e.data.type === 'help').map(e => ({t:Math.round(e.t), otherLocales:e.data.help.otherLocales})) };
      all.push(concise); console.log(JSON.stringify(concise));
      await context.close();
    }
  }
  await Promise.all(Array.from({length:parallel}, run));
  await browser.close();
  fs.writeFileSync(`${dir}/${mode}-summary.json`, JSON.stringify({buildId:build.buildId, count, parallel, budgetMs, initialAssertionFailed:all.filter(x=>x.initialAssertionFailed).length, failed5:all.filter(x=>x.failed5).length, recovered:all.filter(x=>x.recovered).length, all},null,2));
})().catch(e => { console.error(e); process.exitCode = 1; });
