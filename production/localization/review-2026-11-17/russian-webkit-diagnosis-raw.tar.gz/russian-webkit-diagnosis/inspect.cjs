const fs = require('node:fs');
const { webkit } = require('/tmp/prompt-seen-language-review/integration/node_modules/playwright');
const out = '/tmp/prompt-seen-language-review/russian-webkit-diagnosis';
const base = 'http://127.0.0.1:8197';
const expectedBuild = process.env.RU_EXPECTED_BUILD || '0af7dbe6-root';
const label = process.env.RU_DIAG_LABEL || 'old';
const pages = [
  ['home', '/ru/'], ['list', '/ru/prompts/'], ['prompt', '/ru/prompts/dog-home-alone-comic/'],
  ['template', '/ru/templates/birthday-main-character-card/'], ['templates', '/ru/templates/'],
  ['search', '/ru/search/?q=%D0%9F%D1%8F%D1%82%D1%8C'], ['explore', '/ru/explore/'], ['favorites', '/ru/favorites/'],
];
function intlProbe() {
  const locale = 'ru-u-nu-latn';
  return {
    dates: Array.from({ length: 12 }, (_, month) => {
      const date = new Date(Date.UTC(2026, month, 17));
      return { month: month + 1, medium: new Intl.DateTimeFormat(locale, { dateStyle: 'medium', timeZone: 'UTC' }).format(date), shortMonthDay: new Intl.DateTimeFormat(locale, { month: 'short', day: 'numeric', timeZone: 'UTC' }).format(date) };
    }),
    numbers: [0, 1, 2, 4, 5, 21, 285, 1234, 12345.5].map(value => [value, new Intl.NumberFormat(locale).format(value), new Intl.PluralRules(locale).select(value)]),
    languages: ['en', 'zh', 'ja', 'ko', 'ru', 'fr', 'de', 'it'].map(code => [code, new Intl.DisplayNames(['ru'], { type: 'language' }).of(code)]),
  };
}
function textNodes() {
  const nodes = [];
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (!node.textContent.trim() || node.parentElement?.closest('script,style,noscript')) continue;
    nodes.push({ text: node.textContent, tag: node.parentElement?.tagName, class: node.parentElement?.className, lang: node.parentElement?.closest('[lang]')?.lang });
  }
  return nodes;
}
(async () => {
  fs.mkdirSync(out, { recursive: true });
  const build = await (await fetch(`${base}/generated/build.json`)).json();
  if (build.buildId !== expectedBuild) throw new Error(`Unexpected build ${build.buildId}`);
  console.log(JSON.stringify({ buildId: build.buildId }));
  const browser = await webkit.launch({ headless: true });
  try {
    const serverContext = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 1440, height: 900 } });
    const clientContext = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const server = await serverContext.newPage();
    const client = await clientContext.newPage();
    const errors = [];
    client.on('pageerror', error => errors.push({ type: 'pageerror', message: error.message }));
    client.on('console', message => { if (message.type() === 'error') errors.push({ type: 'console', message: message.text() }); });
    const results = [];
    for (const [name, path] of pages) {
      errors.length = 0;
      await server.goto(`${base}${path}`);
      const ssr = await server.evaluate(textNodes);
      await client.goto(`${base}${path}`);
      await client.waitForFunction(() => { const element = document.querySelector('header button, header a[href]'); return !!element && Object.keys(element).some(key => key.startsWith('__react')); });
      await client.waitForTimeout(250);
      const hydrated = await client.evaluate(textNodes);
      const result = { name, path, errors: [...errors], ssr, hydrated };
      fs.writeFileSync(`${out}/${label}-${name}.json`, JSON.stringify(result, null, 2));
      results.push({ name, path, errors: [...errors], ssrNodes: ssr.length, clientNodes: hydrated.length });
      console.log(JSON.stringify(results.at(-1)));
    }
    const intl = { node: intlProbe(), webkit: await client.evaluate(intlProbe) };
    fs.writeFileSync(`${out}/${label}-intl.json`, JSON.stringify(intl, null, 2));
    fs.writeFileSync(`${out}/${label}-summary.json`, JSON.stringify({ buildId: build.buildId, results }, null, 2));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
